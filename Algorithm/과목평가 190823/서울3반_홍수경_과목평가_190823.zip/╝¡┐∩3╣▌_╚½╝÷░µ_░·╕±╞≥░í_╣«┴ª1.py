import sys
sys.stdin = open('문제1.txt', 'r')


T = int(input())

for tc in range(T):
    n, m = list(map(int, input().split()))
    arr = [list(map(int, input().split())) for _ in range(m)]

    check = [[0] * n for _ in range(n)]


    for i in range(len(arr)):
        for y in range((arr[i][2] - arr[i][0]) +1):
            for j in range((arr[i][3] - arr[i][1]) +1):
                check[(arr[i][0]-1) + y][arr[i][1]-1+j] += 1


    result = 0
    for i in range(len(check)):
        for j in range(len(check[i])):
            if check[i][j] > 0:
                result += 1


    print('#{} {}' .format(tc+1, result))